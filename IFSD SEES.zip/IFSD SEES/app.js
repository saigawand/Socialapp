const express = require('express');
const app = express();
const port = 3000;

const bodyParser = require('body-parser');
app.use(bodyParser.json());

const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://sairajendragbsc22:vlVcF0CREaQm6j4J@cluster0.aordgu9.mongodb.net/trips', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

const tripSchema = new mongoose.Schema({
  cost: Number,
});

const Trip = mongoose.model('Trip', tripSchema);

// GET all trips
app.get('/api/trips', (req, res) => {
  Trip.find({}, (err, trips) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to retrieve trips' });
    } else {
      res.json(trips);
    }
  });
});

// POST (create) a new trip
app.post('/api/trips', (req, res) => {
  const trip = new Trip(req.body);

  trip.save((err, savedTrip) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to save trip' });
    } else {
      res.json(savedTrip);
    }
  });
});

// PUT (update) a trip
app.put('/api/trips/:id', (req, res) => {
  Trip.findByIdAndUpdate(req.params.id, req.body, { new: true }, (err, updatedTrip) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to update trip' });
    } else {
      res.json(updatedTrip);
    }
  });
});


// DELETE a trip
app.delete('/api/trips/:id', (req, res) => {
  Trip.findByIdAndDelete(req.params.id, (err) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Failed to delete trip' });
    } else {
      res.sendStatus(200);
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
